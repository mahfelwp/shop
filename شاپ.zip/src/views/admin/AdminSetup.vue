<script setup lang="ts">
import { ref } from 'vue'
import { createClient } from '@supabase/supabase-js'
import { Copy, Check } from 'lucide-vue-next'

const loading = ref(false)
const message = ref('')
const isError = ref(false)
const activeTab = ref<'admin' | 'sql'>('admin')
const copied = ref(false)

const form = ref({
  serviceKey: '',
  mobile: '09369619510',
  password: 'admin123',
  fullName: 'مدیر سیستم'
})

// SQL Code for Database Setup
const sqlCode = `-- ==========================================
-- کدهای آپدیت دیتابیس (رفع خطای 400 و ستون‌های جدید)
-- ==========================================

-- 1. تنظیمات نوع URL (رفع خطای PGRST204)
alter table public.site_settings 
add column if not exists product_url_type text default 'id'; -- 'id' or 'slug'

-- 2. اضافه کردن اسلاگ به محصولات
alter table public.products 
add column if not exists slug text unique;

-- 3. اصلاح تنظیمات باکت تصاویر (رفع خطای 400 آپلود)
insert into storage.buckets (id, name, public)
values ('receipts', 'receipts', true)
on conflict (id) do update set public = true;

update storage.buckets set public = true where id = 'receipts';

-- 4. اضافه کردن ستون‌های هزینه ارسال
alter table public.orders 
add column if not exists shipping_payment_status text default 'waived',
add column if not exists shipping_payment_token uuid default gen_random_uuid(),
add column if not exists shipping_cost_real decimal default 0,
add column if not exists shipping_receipt_url text;

-- 5. تنظیمات امنیتی باکت‌ها
drop policy if exists "Public Access to Receipts" on storage.objects;
create policy "Public Access to Receipts" on storage.objects for select using ( bucket_id = 'receipts' );

-- 6. اضافه کردن ستون‌های روش‌های ارسال
alter table public.shipping_methods 
add column if not exists cost_type text default 'fixed' check (cost_type in ('fixed', 'pas_kerayeh', 'calculated_later'));

-- 7. رفرش کردن کش Schema (اختیاری)
NOTIFY pgrst, 'reload schema';
`

const copySql = () => {
  navigator.clipboard.writeText(sqlCode)
  copied.value = true
  setTimeout(() => copied.value = false, 2000)
}

const createOrFixAdmin = async () => {
  if (!form.value.serviceKey) {
    message.value = 'لطفا Service Role Key را وارد کنید'
    isError.value = true
    return
  }

  if (form.value.password.length < 6) {
    message.value = 'رمز عبور باید حداقل ۶ کاراکتر باشد'
    isError.value = true
    return
  }

  loading.value = true
  message.value = 'در حال برقراری ارتباط با سرور...'
  isError.value = false

  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
    const adminClient = createClient(supabaseUrl, form.value.serviceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    let phone = form.value.mobile.trim()
    phone = phone.replace(/[^\d+]/g, '')
    if (phone.startsWith('09')) phone = '+98' + phone.substring(1)
    else if (phone.startsWith('9')) phone = '+98' + phone

    message.value = 'در حال بررسی حساب کاربری...'

    const { data: createData, error: createError } = await adminClient.auth.admin.createUser({
      phone: phone,
      password: form.value.password,
      email_confirm: true,
      phone_confirm: true,
      user_metadata: {
        full_name: form.value.fullName,
        role: 'admin'
      }
    })

    let userId = createData.user?.id

    if (createError) {
      if (createError.message?.includes('registered') || createError.message?.includes('exists') || createError.status === 422) {
        message.value = 'کاربر یافت شد. در حال بروزرسانی اطلاعات...'
        const { data: listData } = await adminClient.auth.admin.listUsers({ perPage: 1000 })
        const searchPhone = phone.replace('+98', '')
        const foundUser = listData.users.find(u => u.phone?.includes(searchPhone))
        
        if (foundUser) {
          userId = foundUser.id
          await adminClient.auth.admin.updateUserById(userId, {
            password: form.value.password,
            user_metadata: { role: 'admin', full_name: form.value.fullName }
          })
        } else {
          throw new Error('شماره موبایل در سیستم ثبت شده اما ID کاربر یافت نشد.')
        }
      } else {
        throw createError
      }
    }

    if (!userId) throw new Error('شناسه کاربر (User ID) یافت نشد.')

    message.value = 'در حال تنظیم دسترسی مدیریت...'
    await new Promise(r => setTimeout(r, 2000))

    const { error: updateError } = await adminClient
      .from('profiles')
      .update({
        role: 'admin',
        full_name: form.value.fullName,
        phone: phone,
      })
      .eq('id', userId)

    if (updateError) {
      const { error: upsertError } = await adminClient
        .from('profiles')
        .upsert({
          id: userId,
          role: 'admin',
          full_name: form.value.fullName,
          phone: phone
        })
      if (upsertError) throw upsertError
    }

    message.value = '✅ تبریک! حساب ادمین با موفقیت ساخته/آپدیت شد.'
    isError.value = false

  } catch (e: any) {
    console.error(e)
    message.value = '❌ خطا: ' + (e.message || e)
    isError.value = true
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-slate-100 font-sans p-4">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden">
      
      <!-- Tabs -->
      <div class="flex border-b border-slate-100">
        <button 
          @click="activeTab = 'admin'" 
          class="flex-1 py-4 text-sm font-bold transition"
          :class="activeTab === 'admin' ? 'bg-indigo-50 text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:bg-slate-50'"
        >
          ساخت ادمین
        </button>
        <button 
          @click="activeTab = 'sql'" 
          class="flex-1 py-4 text-sm font-bold transition"
          :class="activeTab === 'sql' ? 'bg-indigo-50 text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:bg-slate-50'"
        >
          SQL دیتابیس (رفع خطا)
        </button>
      </div>

      <!-- Admin Tab -->
      <div v-if="activeTab === 'admin'" class="p-8">
        <div class="text-center mb-6">
          <h1 class="text-2xl font-black text-slate-800">پنل نجات اضطراری</h1>
          <p class="text-xs text-slate-400 mt-1">ساخت یا بازیابی دسترسی ادمین</p>
        </div>
        
        <div v-if="message" class="p-4 rounded-xl mb-6 text-sm font-bold leading-relaxed" :class="isError ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-green-50 text-green-600 border border-green-100'">
          {{ message }}
        </div>

        <form @submit.prevent="createOrFixAdmin" class="space-y-4">
          <div class="bg-yellow-50 p-3 rounded-lg border border-yellow-200 text-xs text-yellow-800 leading-relaxed">
            <strong class="block mb-1">نکته مهم:</strong>
            مطمئن شوید که <strong>Service Role Key</strong> را وارد می‌کنید.
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-500 mb-1">Service Role Key</label>
            <input v-model="form.serviceKey" type="password" required class="w-full p-3 border border-slate-200 rounded-xl dir-ltr text-left font-mono text-xs focus:border-indigo-500 outline-none transition-colors" placeholder="eyJhbGciOiJIUzI1NiIsIn..." />
          </div>

          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-bold text-slate-500 mb-1">شماره موبایل</label>
              <input v-model="form.mobile" type="text" class="w-full p-3 border border-slate-200 rounded-xl dir-ltr text-left focus:border-indigo-500 outline-none transition-colors" />
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-500 mb-1">رمز عبور جدید</label>
              <input v-model="form.password" type="text" class="w-full p-3 border border-slate-200 rounded-xl dir-ltr text-left focus:border-indigo-500 outline-none transition-colors" />
            </div>
          </div>

          <button :disabled="loading" type="submit" class="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex justify-center items-center gap-2">
            <span v-if="loading" class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
            <span>{{ loading ? 'در حال پردازش...' : 'اعمال نقش ادمین' }}</span>
          </button>
        </form>
      </div>

      <!-- SQL Tab -->
      <div v-if="activeTab === 'sql'" class="p-8">
        <div class="text-center mb-6">
          <h1 class="text-xl font-black text-slate-800">آپدیت دیتابیس</h1>
          <p class="text-xs text-slate-500 mt-1">برای رفع خطای PGRST204 و 400</p>
        </div>

        <div class="bg-slate-900 rounded-xl p-4 relative group">
          <button 
            @click="copySql" 
            class="absolute top-2 right-2 bg-white/10 hover:bg-white/20 text-white p-2 rounded-lg transition flex items-center gap-2 text-xs font-bold"
          >
            <Check v-if="copied" class="w-4 h-4" />
            <Copy v-else class="w-4 h-4" />
            {{ copied ? 'کپی شد!' : 'کپی کد' }}
          </button>
          <pre class="text-left dir-ltr text-xs text-green-400 font-mono overflow-x-auto h-64 custom-scrollbar"><code>{{ sqlCode }}</code></pre>
        </div>

        <div class="mt-6 space-y-2 text-sm text-slate-600">
          <p class="font-bold">راهنما:</p>
          <ol class="list-decimal list-inside space-y-1">
            <li>کد بالا را کپی کنید.</li>
            <li>به پنل <a href="https://supabase.com/dashboard" target="_blank" class="text-indigo-600 underline">Supabase</a> بروید.</li>
            <li>از منوی سمت چپ، گزینه <strong>SQL Editor</strong> را انتخاب کنید.</li>
            <li>یک کوئری جدید بسازید، کد را پیست کنید و دکمه <strong>Run</strong> را بزنید.</li>
          </ol>
        </div>
      </div>

      <div class="p-4 bg-slate-50 text-center border-t border-slate-100">
        <router-link to="/login" class="text-sm font-bold text-slate-500 hover:text-indigo-600 transition-colors">
          بازگشت به صفحه ورود
        </router-link>
      </div>
    </div>
  </div>
</template>

<style scoped>
.custom-scrollbar::-webkit-scrollbar {
  height: 8px;
  width: 8px;
}
.custom-scrollbar::-webkit-scrollbar-track {
  background: #1e293b;
}
.custom-scrollbar::-webkit-scrollbar-thumb {
  background: #475569;
  border-radius: 4px;
}
</style>