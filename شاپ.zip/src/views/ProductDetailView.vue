<script setup lang="ts">
import { ref, computed, watch, onBeforeUnmount } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { supabase } from '@/lib/supabase'
import { useCartStore } from '@/stores/cart'
import { useSettingsStore } from '@/stores/settings'
import {
  ShoppingCart,
  ArrowRight,
  Truck,
  ShieldCheck,
  Heart,
  Video,
  Star,
  Share2,
  Minus,
  Plus,
  ChevronLeft,
  X,
  Play,
} from 'lucide-vue-next'
import ProductComments from '@/components/product/ProductComments.vue'
import { useHead } from '@vueuse/head'

type Product = {
  id: number
  slug: string | null
  title: string
  description: string | null
  category: string | null
  is_featured: boolean | null
  price: number
  image: string | null
  gallery: string[] | null
  video: string | null
  stock: number
}

type RelatedProduct = Pick<Product, 'id' | 'slug' | 'title' | 'price' | 'image' | 'category'>

type MediaItem =
  | { type: 'image'; src: string; thumb: string }
  | { type: 'video'; src: string; thumb: string }

const route = useRoute()
const router = useRouter()
const cartStore = useCartStore()
const settingsStore = useSettingsStore()

const product = ref<Product | null>(null)
const relatedProducts = ref<RelatedProduct[]>([])
const loading = ref(false)

const selectedImage = ref('')
const quantity = ref(1)

/* ----------------------------- UI states ----------------------------- */
const activeTab = ref<'desc' | 'video' | 'comments'>('desc')

// lightbox
const lightboxOpen = ref(false)
const lightboxIndex = ref(0)

/* ----------------------------- Route param ---------------------------- */
const rawParam = computed(() => {
  const p = route.params.id
  return Array.isArray(p) ? (p[0] ?? '') : String(p ?? '')
})

const isNumericId = (value: string) => /^\d+$/.test(value)

/* ------------------------------ Computeds ----------------------------- */
const formattedPrice = computed(() => {
  const price = product.value?.price
  return typeof price === 'number' ? price.toLocaleString() : ''
})

const fullDescription = computed(() => product.value?.description?.trim() || 'توضیحات محصول به زودی اضافه می‌شود.')

const shortDescription = computed(() => {
  const txt = product.value?.description?.trim()
  if (!txt) return 'توضیحات محصول به زودی اضافه می‌شود.'
  return txt.length > 180 ? `${txt.slice(0, 180)}...` : txt
})

const stock = computed(() => product.value?.stock ?? 0)
const inStock = computed(() => stock.value > 0)
const maxQty = computed(() => (inStock.value ? stock.value : 1))

const canIncrement = computed(() => inStock.value && quantity.value < maxQty.value)
const canDecrement = computed(() => quantity.value > 1)

function clampQty() {
  if (quantity.value < 1) quantity.value = 1
  if (quantity.value > maxQty.value) quantity.value = maxQty.value
}

const imageList = computed(() => {
  const p = product.value
  if (!p) return []
  const imgs: string[] = []
  if (p.image) imgs.push(p.image)
  if (Array.isArray(p.gallery)) imgs.push(...p.gallery.filter(Boolean))
  return Array.from(new Set(imgs))
})

const mediaItems = computed<MediaItem[]>(() => {
  const p = product.value
  if (!p) return []

  const items: MediaItem[] = []

  // Images
  for (const img of imageList.value) {
    items.push({ type: 'image', src: img, thumb: img })
  }

  // Video as a "thumbnail" (uses poster = main image if available)
  if (p.video) {
    const poster = p.image || imageList.value[0] || ''
    items.unshift({ type: 'video', src: p.video, thumb: poster })
  }

  return items
})

const currentSelectedMediaIndex = computed(() => {
  // if video is active tab, selection is not image-based; keep simple:
  const idx = mediaItems.value.findIndex((m) => m.type === 'image' && m.src === selectedImage.value)
  return idx >= 0 ? idx : 0
})

/* ----------------------------- Settings ----------------------------- */
async function ensureSettingsLoaded() {
  if (!settingsStore.isLoaded) await settingsStore.fetchSettings()
}

function canonicalParamFor(p: Product): string {
  const urlType = settingsStore.settings?.product_url_type || 'id'
  if (urlType === 'slug' && p.slug) return p.slug
  return String(p.id)
}

function routeParamFor(p: { id: number; slug: string | null }): string {
  const urlType = settingsStore.settings?.product_url_type || 'id'
  if (urlType === 'slug' && p.slug) return p.slug
  return String(p.id)
}

/* ----------------------------- Supabase fetch ----------------------------- */
async function fetchProduct(param: string): Promise<Product | null> {
  let query = supabase
    .from('products')
    .select('id, slug, title, description, category, is_featured, price, image, gallery, video, stock')

  query = isNumericId(param) ? query.eq('id', Number(param)) : query.eq('slug', param)

  const { data, error } = await query.single<Product>()
  if (error) return null
  return data ?? null
}

async function fetchRelatedProducts(category: string, currentId: number) {
  const { data } = await supabase
    .from('products')
    .select('id, slug, title, price, image, category')
    .eq('category', category)
    .neq('id', currentId)
    .order('id', { ascending: false })
    .limit(4)

  relatedProducts.value = (data ?? []) as RelatedProduct[]
}

/* ----------------------------- Load orchestration ----------------------------- */
let loadSeq = 0

async function load() {
  const seq = ++loadSeq
  const param = rawParam.value.trim()

  if (!param) {
    product.value = null
    relatedProducts.value = []
    selectedImage.value = ''
    quantity.value = 1
    activeTab.value = 'desc'
    return
  }

  loading.value = true
  relatedProducts.value = []

  try {
    await ensureSettingsLoaded()

    const data = await fetchProduct(param)
    if (seq !== loadSeq) return

    if (!data) {
      product.value = null
      selectedImage.value = ''
      await router.replace({ name: 'products' })
      return
    }

    // Canonical redirect
    const canonical = canonicalParamFor(data)
    if (canonical !== param) {
      await router.replace({
        name: 'product-detail',
        params: { id: canonical },
        query: route.query,
        hash: route.hash,
      })
      return
    }

    product.value = data
    quantity.value = 1
    clampQty()

    // pick initial media
    const imgs = imageList.value
    selectedImage.value = imgs.includes(selectedImage.value) ? selectedImage.value : (imgs[0] ?? '')

    // default tab: if there is a video, keep desc; user can switch
    activeTab.value = 'desc'

    if (data.category) void fetchRelatedProducts(data.category, data.id)
  } finally {
    if (seq === loadSeq) loading.value = false
  }
}

watch(rawParam, () => void load(), { immediate: true })
watch(stock, clampQty)

/* ----------------------------- Actions ----------------------------- */
function addToCart() {
  if (!product.value) return
  if (!inStock.value) return
  clampQty()
  for (let i = 0; i < quantity.value; i++) cartStore.addItem(product.value)
}

function incrementQty() {
  if (canIncrement.value) quantity.value++
}

function decrementQty() {
  if (canDecrement.value) quantity.value--
}

function goToRelated(rel: RelatedProduct) {
  router.push({ name: 'product-detail', params: { id: routeParamFor(rel) } })
}

async function shareProduct() {
  const p = product.value
  if (!p) return
  const url = window.location.href
  const title = p.title
  const text = shortDescription.value

  // Web Share API (mobile-friendly)
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url })
      return
    } catch {
      // ignore cancel
    }
  }

  // fallback: copy link
  try {
    await navigator.clipboard.writeText(url)
    alert('لینک محصول کپی شد.')
  } catch {
    prompt('لینک را کپی کنید:', url)
  }
}

/* ----------------------------- Lightbox ----------------------------- */
function openLightbox(index?: number) {
  const items = mediaItems.value
  if (!items.length) return
  lightboxIndex.value = typeof index === 'number' ? index : currentSelectedMediaIndex.value
  lightboxOpen.value = true
}

function closeLightbox() {
  lightboxOpen.value = false
}

function nextLightbox() {
  const items = mediaItems.value
  if (!items.length) return
  lightboxIndex.value = (lightboxIndex.value + 1) % items.length
}

function prevLightbox() {
  const items = mediaItems.value
  if (!items.length) return
  lightboxIndex.value = (lightboxIndex.value - 1 + items.length) % items.length
}

function onKeydown(e: KeyboardEvent) {
  if (!lightboxOpen.value) return
  if (e.key === 'Escape') closeLightbox()
  if (e.key === 'ArrowRight') prevLightbox() // RTL-friendly
  if (e.key === 'ArrowLeft') nextLightbox()
}

window.addEventListener('keydown', onKeydown)
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown))

/* -------------------------------- SEO -------------------------------- */
useHead({
  title: computed(() => (product.value ? `${product.value.title} | فروشگاه` : 'محصول | فروشگاه')),
  meta: [
    {
      name: 'description',
      content: computed(() => {
        if (!product.value) return 'مشاهده جزئیات محصول و خرید آنلاین.'
        const cat = product.value.category ? ` در دسته‌بندی ${product.value.category}` : ''
        return `${shortDescription.value}${cat}`
      }),
    },
    { property: 'og:type', content: 'product' },
    { property: 'og:title', content: computed(() => (product.value ? product.value.title : 'محصول')) },
    { property: 'og:description', content: computed(() => shortDescription.value) },
    { property: 'og:image', content: computed(() => product.value?.image || product.value?.gallery?.[0] || '') },
  ],
})
</script>

<template>
  <!-- add extra padding bottom for mobile sticky bar -->
  <div class="bg-[#fafaf9] min-h-screen pt-24 pb-28 md:pb-20 font-sans text-stone-800">
    <div class="container mx-auto px-4 md:px-8 max-w-7xl">
      <!-- Breadcrumbs -->
      <nav
        v-if="product"
        class="flex items-center gap-2 text-sm text-stone-500 mb-6 md:mb-8 overflow-x-auto whitespace-nowrap pb-2"
      >
        <router-link to="/" class="hover:text-stone-900 transition-colors">خانه</router-link>
        <ChevronLeft class="w-3 h-3 text-stone-300" />
        <router-link to="/products" class="hover:text-stone-900 transition-colors">فروشگاه</router-link>
        <ChevronLeft class="w-3 h-3 text-stone-300" />
        <span class="text-stone-900 font-bold truncate">{{ product.title }}</span>
      </nav>

      <!-- Loading -->
      <div v-if="loading" class="flex justify-center py-28 md:py-32">
        <div class="flex flex-col items-center gap-4">
          <div class="w-10 h-10 border-2 border-stone-200 border-t-stone-800 rounded-full animate-spin"></div>
          <span class="text-stone-400 text-sm">در حال بارگذاری...</span>
        </div>
      </div>

      <div v-else-if="product" class="animate-fade-in">
        <!-- HERO: Gallery + Sticky purchase box -->
        <div class="grid lg:grid-cols-12 gap-10 lg:gap-14 mb-16 md:mb-20">
          <!-- Gallery -->
          <div class="lg:col-span-7">
            <div class="lg:sticky lg:top-28">
              <div class="grid gap-4 lg:grid-cols-[88px_1fr]">
                <!-- Thumbs (desktop vertical) -->
                <div class="hidden lg:flex lg:flex-col gap-3">
                  <button
                    v-for="(m, idx) in mediaItems"
                    :key="m.type + m.src + idx"
                    type="button"
                    @click="m.type === 'video' ? (activeTab = 'video') : (selectedImage = m.src)"
                    class="relative w-[88px] h-[88px] rounded-2xl overflow-hidden border-2 bg-white transition"
                    :class="
                      (m.type === 'video' && activeTab === 'video') || (m.type === 'image' && selectedImage === m.src)
                        ? 'border-stone-900'
                        : 'border-transparent hover:border-stone-200'
                    "
                    :aria-label="m.type === 'video' ? 'نمایش ویدیو' : 'انتخاب تصویر'"
                  >
                    <img :src="m.thumb" alt="" class="w-full h-full object-cover" loading="lazy" decoding="async" />
                    <div
                      v-if="m.type === 'video'"
                      class="absolute inset-0 bg-black/25 flex items-center justify-center"
                    >
                      <div class="w-9 h-9 rounded-full bg-white/90 flex items-center justify-center">
                        <Play class="w-4 h-4 text-stone-900" />
                      </div>
                    </div>
                  </button>
                </div>

                <!-- Main visual -->
                <div>
                  <div
                    class="aspect-[4/3] lg:aspect-[16/11] rounded-3xl overflow-hidden bg-white shadow-sm border border-stone-100 relative group"
                  >
                    <button
                      v-if="activeTab !== 'video'"
                      type="button"
                      class="absolute inset-0 z-10 cursor-zoom-in"
                      @click="openLightbox()"
                      aria-label="بزرگنمایی تصویر"
                    ></button>

                    <img
                      v-if="activeTab !== 'video' && selectedImage"
                      :src="selectedImage"
                      :alt="product.title"
                      class="w-full h-full object-cover transition duration-700 group-hover:scale-105"
                      decoding="async"
                      fetchpriority="high"
                    />

                    <div v-else class="w-full h-full bg-black">
                      <video
                        v-if="product.video"
                        controls
                        class="w-full h-full object-cover"
                        :poster="product.image || ''"
                      >
                        <source :src="product.video" type="video/mp4" />
                        مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
                      </video>
                    </div>

                    <div
                      v-if="product.is_featured"
                      class="absolute top-4 right-4 bg-stone-900 text-white text-[10px] font-bold px-3 py-1.5 rounded-full tracking-wide z-20"
                    >
                      ویژه
                    </div>
                  </div>

                  <!-- Thumbs (mobile horizontal) -->
                  <div class="lg:hidden flex gap-3 overflow-x-auto pb-2 pt-4 scrollbar-hide">
                    <button
                      v-for="(m, idx) in mediaItems"
                      :key="m.type + m.src + idx"
                      type="button"
                      @click="m.type === 'video' ? (activeTab = 'video') : (selectedImage = m.src)"
                      class="relative w-20 h-20 rounded-2xl overflow-hidden border-2 bg-white flex-shrink-0 transition"
                      :class="
                        (m.type === 'video' && activeTab === 'video') || (m.type === 'image' && selectedImage === m.src)
                          ? 'border-stone-900 opacity-100'
                          : 'border-transparent opacity-75 hover:opacity-100'
                      "
                    >
                      <img :src="m.thumb" alt="" class="w-full h-full object-cover" loading="lazy" decoding="async" />
                      <div
                        v-if="m.type === 'video'"
                        class="absolute inset-0 bg-black/25 flex items-center justify-center"
                      >
                        <div class="w-9 h-9 rounded-full bg-white/90 flex items-center justify-center">
                          <Play class="w-4 h-4 text-stone-900" />
                        </div>
                      </div>
                    </button>
                  </div>

                  <!-- Quick tab chips under gallery (mobile) -->
                  <div class="lg:hidden mt-4 flex gap-2">
                    <button
                      type="button"
                      class="px-4 py-2 rounded-xl text-sm font-bold border transition"
                      :class="activeTab === 'desc' ? 'bg-stone-900 text-white border-stone-900' : 'bg-white border-stone-200 text-stone-700'"
                      @click="activeTab = 'desc'"
                    >
                      توضیحات
                    </button>
                    <button
                      v-if="product.video"
                      type="button"
                      class="px-4 py-2 rounded-xl text-sm font-bold border transition"
                      :class="activeTab === 'video' ? 'bg-stone-900 text-white border-stone-900' : 'bg-white border-stone-200 text-stone-700'"
                      @click="activeTab = 'video'"
                    >
                      ویدیو
                    </button>
                    <button
                      type="button"
                      class="px-4 py-2 rounded-xl text-sm font-bold border transition"
                      :class="activeTab === 'comments' ? 'bg-stone-900 text-white border-stone-900' : 'bg-white border-stone-200 text-stone-700'"
                      @click="activeTab = 'comments'"
                    >
                      نظرات
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Purchase box (sticky) -->
          <div class="lg:col-span-5">
            <div class="lg:sticky lg:top-28 bg-white rounded-3xl border border-stone-100 shadow-sm overflow-hidden">
              <!-- subtle top accent -->
              <div class="h-1.5 bg-gradient-to-r from-accent to-orange-300"></div>

              <div class="p-6 md:p-8">
                <div class="mb-3 flex items-center gap-3">
                  <span class="text-accent font-bold text-xs tracking-wider uppercase">
                    {{ product.category || 'محصول' }}
                  </span>
                  <div class="h-px flex-1 bg-stone-100"></div>
                  <div class="flex items-center gap-1 text-stone-500">
                    <Star class="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span class="text-xs font-bold">۴.۸</span>
                    <span class="text-xs text-stone-400">(۱۲)</span>
                  </div>
                </div>

                <h1 class="text-2xl md:text-3xl font-black text-stone-900 leading-tight mb-4">
                  {{ product.title }}
                </h1>

                <div class="flex items-baseline gap-2 mb-4">
                  <span class="text-3xl font-black text-stone-900">{{ formattedPrice }}</span>
                  <span class="text-stone-500">تومان</span>
                </div>

                <div class="flex flex-wrap gap-2 mb-6">
                  <span
                    class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border"
                    :class="inStock ? 'bg-green-50 text-green-700 border-green-100' : 'bg-red-50 text-red-700 border-red-100'"
                  >
                    <span class="w-2 h-2 rounded-full" :class="inStock ? 'bg-green-500' : 'bg-red-500'"></span>
                    {{ inStock ? `موجود (حداکثر ${stock} عدد)` : 'ناموجود' }}
                  </span>
                  <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border bg-stone-50 text-stone-600 border-stone-200">
                    <Truck class="w-4 h-4" />
                    ارسال سریع
                  </span>
                  <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border bg-stone-50 text-stone-600 border-stone-200">
                    <ShieldCheck class="w-4 h-4" />
                    ضمانت اصالت
                  </span>
                </div>

                <p class="text-stone-600 leading-7 text-justify text-sm md:text-base mb-6">
                  {{ shortDescription }}
                  <a
                    href="#details"
                    class="text-stone-900 font-bold border-b border-stone-300 hover:border-stone-900 transition-colors mr-1 pb-0.5"
                  >
                    توضیحات کامل
                  </a>
                </p>

                <!-- Desktop actions (kept here, but still visible on mobile too) -->
                <div class="space-y-4">
                  <div class="flex items-center gap-3">
                    <div class="flex items-center bg-stone-50 rounded-2xl border border-stone-200 h-14 px-2">
                      <button
                        type="button"
                        @click="incrementQty"
                        :disabled="!canIncrement"
                        class="w-10 h-full flex items-center justify-center text-stone-500 hover:text-stone-900 transition disabled:opacity-40 disabled:cursor-not-allowed"
                        aria-label="افزایش تعداد"
                      >
                        <Plus class="w-5 h-5" />
                      </button>

                      <span class="w-10 text-center font-black text-lg text-stone-900">{{ quantity }}</span>

                      <button
                        type="button"
                        @click="decrementQty"
                        :disabled="!canDecrement"
                        class="w-10 h-full flex items-center justify-center text-stone-500 hover:text-stone-900 transition disabled:opacity-40 disabled:cursor-not-allowed"
                        aria-label="کاهش تعداد"
                      >
                        <Minus class="w-5 h-5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      @click="addToCart"
                      :disabled="!inStock"
                      class="flex-1 bg-stone-900 text-white h-14 rounded-2xl font-bold text-base md:text-lg hover:bg-stone-800 transition-all duration-300 flex items-center justify-center gap-3 shadow-lg shadow-stone-900/10 hover:-translate-y-0.5 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:translate-y-0"
                    >
                      <ShoppingCart class="w-5 h-5" />
                      افزودن به سبد خرید
                    </button>
                  </div>

                  <div class="flex items-center justify-between gap-4 pt-2 border-t border-stone-100">
                    <button
                      type="button"
                      class="flex items-center gap-2 text-sm font-bold text-stone-500 hover:text-stone-900 transition"
                    >
                      <Heart class="w-4 h-4" />
                      علاقه‌مندی
                    </button>

                    <button
                      type="button"
                      @click="shareProduct"
                      class="flex items-center gap-2 text-sm font-bold text-stone-500 hover:text-stone-900 transition"
                    >
                      <Share2 class="w-4 h-4" />
                      اشتراک‌گذاری
                    </button>
                  </div>
                </div>

                <!-- Trust row -->
                <div class="grid grid-cols-3 gap-4 mt-6 bg-stone-50 p-4 rounded-2xl border border-stone-200">
                  <div class="flex flex-col items-center gap-2 text-center">
                    <ShieldCheck class="w-6 h-6 text-stone-500" />
                    <span class="text-[10px] font-bold text-stone-600">اصالت</span>
                  </div>
                  <div class="flex flex-col items-center gap-2 text-center border-r border-l border-stone-200">
                    <Truck class="w-6 h-6 text-stone-500" />
                    <span class="text-[10px] font-bold text-stone-600">ارسال</span>
                  </div>
                  <div class="flex flex-col items-center gap-2 text-center">
                    <ArrowRight class="w-6 h-6 text-stone-500 rotate-180" />
                    <span class="text-[10px] font-bold text-stone-600">بازگشت</span>
                  </div>
                </div>

                <div v-if="!inStock" class="mt-5 bg-red-50 text-red-700 border border-red-100 rounded-2xl p-4 text-sm font-bold">
                  این محصول در حال حاضر ناموجود است.
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- DETAILS: Tabs (reduces scroll + better UX) -->
        <div id="details" class="max-w-5xl mx-auto">
          <div class="bg-white rounded-3xl border border-stone-100 shadow-sm overflow-hidden">
            <div class="p-3 md:p-4 border-b border-stone-100 bg-stone-50">
              <div class="flex gap-2">
                <button
                  type="button"
                  @click="activeTab = 'desc'"
                  class="flex-1 py-2.5 rounded-2xl font-bold text-sm transition"
                  :class="activeTab === 'desc' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-600 hover:text-stone-900'"
                >
                  توضیحات
                </button>
                <button
                  v-if="product.video"
                  type="button"
                  @click="activeTab = 'video'"
                  class="flex-1 py-2.5 rounded-2xl font-bold text-sm transition flex items-center justify-center gap-2"
                  :class="activeTab === 'video' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-600 hover:text-stone-900'"
                >
                  <Video class="w-4 h-4" />
                  ویدیو
                </button>
                <button
                  type="button"
                  @click="activeTab = 'comments'"
                  class="flex-1 py-2.5 rounded-2xl font-bold text-sm transition"
                  :class="activeTab === 'comments' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-600 hover:text-stone-900'"
                >
                  نظرات
                </button>
              </div>
            </div>

            <div class="p-6 md:p-10">
              <div v-if="activeTab === 'desc'">
                <div class="prose prose-stone prose-lg max-w-none leading-loose text-justify text-stone-600">
                  {{ fullDescription }}
                </div>
              </div>

              <div v-else-if="activeTab === 'video'">
                <div v-if="product.video" class="space-y-4">
                  <div class="flex items-center gap-2 text-stone-600 text-sm font-bold">
                    <Video class="w-4 h-4" />
                    ویدیو معرفی محصول
                  </div>
                  <div class="rounded-3xl overflow-hidden shadow-xl bg-black">
                    <video controls class="w-full aspect-video" :poster="product.image || ''">
                      <source :src="product.video" type="video/mp4" />
                      مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
                    </video>
                  </div>
                </div>
                <div v-else class="text-stone-500 text-sm">ویدیویی برای این محصول ثبت نشده است.</div>
              </div>

              <div v-else>
                <ProductComments :productId="product.id" />
              </div>
            </div>
          </div>
        </div>

        <!-- RELATED -->
        <div v-if="relatedProducts.length > 0" class="mt-16 md:mt-24 pt-12 border-t border-stone-200">
          <div class="flex items-center justify-between mb-8 md:mb-10">
            <h3 class="text-xl md:text-2xl font-black text-stone-900">محصولات مشابه</h3>
            <router-link to="/products" class="text-sm font-bold text-stone-500 hover:text-stone-900 flex items-center gap-1">
              مشاهده همه <ArrowRight class="w-4 h-4 rotate-180" />
            </router-link>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            <div
              v-for="rel in relatedProducts"
              :key="rel.id"
              class="group cursor-pointer bg-white rounded-3xl border border-stone-100 shadow-sm hover:shadow-md transition overflow-hidden"
              @click="goToRelated(rel)"
            >
              <div class="aspect-[3/4] bg-stone-100 overflow-hidden relative">
                <img
                  :src="rel.image || ''"
                  :alt="rel.title"
                  class="w-full h-full object-cover transition duration-700 group-hover:scale-105"
                  loading="lazy"
                  decoding="async"
                />
                <div class="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition duration-300"></div>
              </div>
              <div class="p-4">
                <h4 class="font-bold text-stone-900 mb-2 group-hover:text-accent transition line-clamp-2">
                  {{ rel.title }}
                </h4>
                <div class="text-stone-700 font-black text-sm">
                  {{ rel.price.toLocaleString() }}
                  <span class="text-xs font-normal text-stone-400">تومان</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- LIGHTBOX -->
        <div v-if="lightboxOpen" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm" @click.self="closeLightbox">
          <div class="absolute top-4 right-4 flex gap-2">
            <button
              type="button"
              @click="closeLightbox"
              class="w-11 h-11 rounded-2xl bg-white/10 border border-white/15 text-white flex items-center justify-center hover:bg-white/15 transition"
              aria-label="بستن"
            >
              <X class="w-5 h-5" />
            </button>
          </div>

          <div class="h-full w-full flex items-center justify-center px-4">
            <div class="w-full max-w-5xl">
              <div class="rounded-3xl overflow-hidden bg-black border border-white/10 shadow-2xl relative">
                <template v-if="mediaItems[lightboxIndex]?.type === 'video'">
                  <video controls class="w-full aspect-video" :poster="product?.image || ''">
                    <source :src="mediaItems[lightboxIndex]?.src" type="video/mp4" />
                  </video>
                </template>
                <template v-else>
                  <img
                    :src="mediaItems[lightboxIndex]?.src"
                    :alt="product?.title || ''"
                    class="w-full max-h-[80vh] object-contain bg-black"
                  />
                </template>

                <button
                  type="button"
                  @click="prevLightbox"
                  class="absolute top-1/2 -translate-y-1/2 right-3 w-11 h-11 rounded-2xl bg-white/10 border border-white/15 text-white flex items-center justify-center hover:bg-white/15 transition"
                  aria-label="قبلی"
                >
                  <ChevronLeft class="w-5 h-5 rotate-180" />
                </button>
                <button
                  type="button"
                  @click="nextLightbox"
                  class="absolute top-1/2 -translate-y-1/2 left-3 w-11 h-11 rounded-2xl bg-white/10 border border-white/15 text-white flex items-center justify-center hover:bg-white/15 transition"
                  aria-label="بعدی"
                >
                  <ChevronLeft class="w-5 h-5" />
                </button>
              </div>

              <div class="mt-4 flex gap-2 overflow-x-auto scrollbar-hide pb-2">
                <button
                  v-for="(m, idx) in mediaItems"
                  :key="m.type + m.src + 'lb' + idx"
                  type="button"
                  @click="lightboxIndex = idx"
                  class="relative w-20 h-20 rounded-2xl overflow-hidden border-2 bg-white flex-shrink-0 transition"
                  :class="idx === lightboxIndex ? 'border-white' : 'border-transparent opacity-75 hover:opacity-100'"
                >
                  <img :src="m.thumb" alt="" class="w-full h-full object-cover" />
                  <div v-if="m.type === 'video'" class="absolute inset-0 bg-black/25 flex items-center justify-center">
                    <div class="w-9 h-9 rounded-full bg-white/90 flex items-center justify-center">
                      <Play class="w-4 h-4 text-stone-900" />
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- MOBILE STICKY BUY BAR -->
        <div
          class="fixed bottom-0 left-0 right-0 z-40 md:hidden border-t border-stone-200 bg-white/95 backdrop-blur"
        >
          <div class="max-w-7xl mx-auto px-4 py-3">
            <div class="flex items-center gap-3">
              <div class="min-w-0 flex-1">
                <div class="text-[11px] text-stone-500">قیمت</div>
                <div class="font-black text-stone-900 truncate">
                  {{ formattedPrice }}
                  <span class="text-xs font-normal text-stone-500">تومان</span>
                </div>
              </div>

              <div class="flex items-center bg-stone-50 rounded-2xl border border-stone-200 h-12 px-2">
                <button
                  type="button"
                  @click="incrementQty"
                  :disabled="!canIncrement"
                  class="w-9 h-full flex items-center justify-center text-stone-500 disabled:opacity-40 disabled:cursor-not-allowed"
                  aria-label="افزایش تعداد"
                >
                  <Plus class="w-4 h-4" />
                </button>
                <span class="w-8 text-center font-black text-sm text-stone-900">{{ quantity }}</span>
                <button
                  type="button"
                  @click="decrementQty"
                  :disabled="!canDecrement"
                  class="w-9 h-full flex items-center justify-center text-stone-500 disabled:opacity-40 disabled:cursor-not-allowed"
                  aria-label="کاهش تعداد"
                >
                  <Minus class="w-4 h-4" />
                </button>
              </div>

              <button
                type="button"
                @click="addToCart"
                :disabled="!inStock"
                class="h-12 px-5 rounded-2xl font-bold text-sm bg-stone-900 text-white disabled:opacity-60 disabled:cursor-not-allowed"
              >
                افزودن
              </button>
            </div>
          </div>
        </div>
      </div>

      <div v-else class="py-24 text-center text-stone-500">
        محصولی برای نمایش وجود ندارد.
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
</style>